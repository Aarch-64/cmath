#define PI 3.14159265358979323846 // se define PI con los siguientes numeros

extern double a; // se declara la variable como externa, para despues declararla en un unico .c
extern float option; // se declara la variable como externa, para despues declararla en un unico .c

void cmath(); // declara por adelantado la armadura cmath

