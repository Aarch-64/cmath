void IniVideo(); // declara por adelantado la armadura IniVideo
void Exit(); // declara por adelantado la armadura Exit
